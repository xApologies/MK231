# Decision ledger and open questions

## Established in conversation
1. Seven named domains and seven principal constraints as in SEVEN_DOMAINS.md.
2. Axiom: the Seven Domains express Magic as an Existence.
3. Genesis Field mathematics inherited as fantasy substrate; Layer 1 is Genesis plus Seven Domains.
4. Six native realms R/O/Y/G/B/V and White superposed Material Realm; colors do not specify elements or landscapes.
5. Material Realm enables coexistence; humans require assistance to enter native realms.
6. Magic need not consume universal mana; life-like spells need not be conscious.
7. Orthogonal cultivated-stone architecture, living greenery, waterways, romanticized 17th–18th century social identity; nine user images are visual authority.
8. MK147 worldbuilding and sigil infrastructure, `_bricked` mathematics, `_raeon` card game are inheritance sources.

## Illustrations / proposals — NOT locked
- Specific native-realm race allocations (e.g. dragon Red, unicorn Violet).
- Phoenixes, foxes, leviathans as other principal races.
- Dragons' biological sexual dimorphism or intelligence differences.
- Any particular protagonist, novel title, academy, forgotten sentence, ancient city, or crisis.
- Healing by borrowing duration, sword-owner threads, spirit negotiations, autonomous healing spells, and map-based teleportation as universally available techniques.
- Exact formula for the seven-domain admissibility operation.

## Questions deliberately open
1. How does realm compatibility work, and what assists human travel?
2. Which six principal magical populations originate in the six realms? What other species inhabit them?
3. How are fully biological humanoid manifestations realized, including mass, metabolism, inheritance, and aging?
4. What counts as a valid magical statement, and how does it relate to ru’ne and sigil arrays?
5. What is a temporal obligation, and how is it discharged?
6. What is an existing connection, and can one be created or severed?
7. When is consent literal, and when is a covenant a structural biological obligation?
8. What makes a spell life-like, and can it reproduce, mutate, or evolve?
9. What geometric rules govern space, adjacency, interlocking blocks, and curved fabrication?
10. What are the costs, throughput limits, and environmental consequences of material growth?
11. Can every magical expression engage a subset of domains, or must every domain be explicitly represented?
12. How do the seven foundations operate in each isolated realm versus White?
13. What is the precise canonical nomenclature for Thousand Thread / Thousand Threads and Covenant Gardens / Covenant Garden? Latest user usage governs this seed.
14. Which binding-circle mechanics from MK147 should be inherited, adapted, or omitted?

## Working provenance discipline
Use three labels in future additions: **INHERITED** (grounded in source repo), **ADAPTED** (changed for new setting), **NEW** (created here). Mark unaccepted suggestions **PROPOSED** and unresolved issues **OPEN**. Do not silently turn examples into established rules.
