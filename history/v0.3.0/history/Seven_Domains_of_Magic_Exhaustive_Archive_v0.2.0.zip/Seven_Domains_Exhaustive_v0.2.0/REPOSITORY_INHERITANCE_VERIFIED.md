# Repository inheritance — verified entry points and scope

This archive inherits *knowledge*, not automatic authority to rewrite upstream repositories. The following files were fetched from GitHub during this thread.

## _bricked — Genesis mathematical substrate

Repo: https://github.com/xApologies/_bricked
README: https://github.com/xApologies/_bricked/blob/main/README.md

The README identifies four Genesis runtime domains: State (R5/D5), Nexus (H6/D6), Shell (Sigma7:8/D7+D8), Sea (S9:11/D9+D10+D11), with Sea↔Shell↔Nexus↔State adjacency. It points to `genesis_mathematics/README.md`, `chirality_fabric/README.md`, structural language, `genesis/systems/rainbow_road/README.md`, registries, and provenance. **These four `_bricked` domains are NOT the new novel's Seven Domains.** The author specifically instructed us to inherit Genesis mathematics, chirality fabric, Rainbow Road, resolution, bandwidth and transduction-relevant structural tools while disregarding game/computer architecture as a required novel mechanic. The README cautions that open mathematics remains open; this archive does not claim to resolve it.

## Mk-147 — fantasy civilization and infrastructure

Repo: https://github.com/xApologies/Mk-147
README: https://github.com/xApologies/Mk-147/blob/main/README.md
Index: https://github.com/xApologies/Mk-147/blob/main/INDEX.md

Verified documents:

**Sigil engineering:** https://github.com/xApologies/Mk-147/blob/main/live-model/04_SYSTEMS/SIGIL_ENGINEERING.md
- `ru’ne` is a discrete, physically inscribed, strongly orthogonal geometric element of a sigil.
- A sigil is a complete physical structure of ru’ne on a substrate.
- A sigil array is a coordinated system of sigils whose combined topology produces system-scale effects.
- Activation may be manual, continuous or conditional; persistence is chiefly substrate/geometry persistence.
- Applications explicitly include water, sanitation/dissolution, lighting, barriers, industrial material growth, maege-glass production, metropolitan Genesis-field stabilization and equipment effects.
- Material-growth arrays support civilization without exclusive reliance on mining/extraction.

**Architects and velis:** https://github.com/xApologies/Mk-147/blob/main/live-model/04_SYSTEMS/ARCHITECTS_VELIS.md
- `velis` is a localized temporarily persistent Genesis-field topology created by an Architect, *not* a physical sigil.
- Coherence and usage affect persistence; some low-load velis may last decades or centuries; maintenance is possible.
- Agricultural velis can accelerate plant growth/nutrient uptake; defensive velis also exist.
- Preserve distinction: ru’ne (component), sigil (physical structure), array (coordinated physical system), velis (field topology).

**Settlements:** https://github.com/xApologies/Mk-147/blob/main/live-model/02_WORLD/KINGDOM_SETTLEMENTS.md
- Crown hierarchy Capital City→Large City→Small City→Village Hub; organic towns are a separate class.
- Example large city ~10×10 miles, small city ~7×7 miles; maturation often ~60–80 years plus major redevelopment, not universal clocks.
- Metropolitan sigil arrays may stabilize the surrounding Genesis Field; example five sigils (four corners and center), radius on the order of 200 miles. These are *MK147 examples*, not automatically imposed on the new novel.
- Stabilized territory and the Wilds are distinguished by Genesis risk, not biome.

**Alchemy:** https://github.com/xApologies/Mk-147/blob/main/live-model/04_SYSTEMS/ALCHEMY.md — the index explicitly refers to a **Type 1–5 scaffold**. The author recalled Types 1–4 and wondered about Type 5; the repo index supports that a Type 1–5 scaffold exists, but this archive does not invent its definitions or claim all tiers are finalized.

**Shaping:** https://github.com/xApologies/Mk-147/blob/main/live-model/04_SYSTEMS/BINDING_VAEN.md — indexed for shaping/PSSP, fatigue and binding circles. Binding circles are **optional inheritance**, not automatically canonized in this new setting.

Mk147's README states explicit Genesis decisions/corrections take priority, with later dedicated canon and provenance handling. Reuse should be selective and should not mutate its accepted world/novel canon.

## _raeon — cultural game, not an eighth domain

Repo: https://github.com/xApologies/_raeon
README: https://github.com/xApologies/_raeon/blob/main/README.md

The game has its own accepted design/data/game/test authority flow. It can exist as a widely played game in the new civilization, as the author requested. This does not mean its game mechanics dictate the Seven Domains or that the new book inherits its development/implementation roadmap.

## Reference images

The author provided **nine architectural reference images earlier in the originating conversation** and explicitly declared them authoritative for the Material Realm. The archive cannot substitute assistant-generated fantasy-city images. This ZIP contains textual descriptions and a manifest note; the original nine image files were not included in this package. When working visually in a new conversation, attach those nine images again if exact visual comparison is needed.
