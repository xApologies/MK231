# Layer architecture and inherited civilization

## Layers
- **Layer 0 — mathematical substrate:** Genesis mathematics inherited conceptually from `_bricked`: geometry, resolution, bandwidth, persistence, chirality fabric, Rainbow Road, admissibility, transduction. Its 11-dimensional computer/game runtime is **not** automatically a requirement of this fantasy.
- **Layer 1 — fantasy engine:** Genesis Field **plus the Seven Domains of Magic**. The domains express magic as existence. Layer 0/1 is a documentation distinction between mathematics and its fantasy expression, not two rival engines.
- **Layer 2 — geography and civilization:** independent geography (rivers, mountains, forests, tundra, climate, landscapes) and civilization (cities, infrastructure, agriculture, trade, culture, architecture).
- **Layer 3 — conscious inhabitants:** humans, elves, dwarves, six realm-native magical populations, individuals, agency, identity, and social relationships.
- **Layer 4 — story engine:** plot, character decisions, conflict, narrative arcs. No protagonist or plot is yet locked.

## Material Realm identity
The White/Material Realm is the superposition of Red through Violet and the shared place of coexistence. Ordinary humans cannot naturally leave it without assistance; native magical beings can visit. Human/elf/dwarf are familiar humanoid morphologies, while magical entities may manifest as humanoids. The biology and reproduction of these manifestations remain open.

## Established visual and civilizational identity
The user's **nine supplied architectural reference images** in the originating chat are visual authority; they are not embedded in this portable seed. Do not replace their design with generic fantasy Renaissance architecture.

Late-17th- to early-18th-century **romanticized preindustrial society**, with a divergent technological trajectory. **Strongly orthogonal**, Minecraft-like grown-block architecture: cubic/rectangular modules, square towers, flat lintels, stepped profiles, precise interlocks, planar geometry. Curves and arches are possible but require more sophisticated growth geometry or finishing work; they are not the default. Straight edges are visually broken up by **living greenery and abundant flowing water**: trees, vines, gardens, canals, fountains, cascades, and waterways supported by sigil systems. The aesthetic is everyday civic identity, not exclusive to elites. Beauty does not require social utopia.

Matter can be grown inside bounded Genesis-field arrays; once grown and disengaged, a solid stone block remains a block without an ongoing sustaining spell. This reduces dependence on quarrying and mining but does not yet establish zero cost or infinite throughput. The alchemy Type 1–5 scaffold should be inherited with exact boundaries verified from MK147. Material composition, resolution, bandwidth, growth rates, energy accounting, and complexity costs require later formalization.

## MK147 canon terminology confirmed from repository
- `ru’ne`: discrete physically inscribed, strongly orthogonal geometric sigil component.
- `sigil`: complete physical structure made of ru’ne, requiring a substrate.
- `sigil array`: coordinated multiple sigils; applications include water, sanitation/dissolution, lighting, barriers, industrial material growth, and metropolitan Genesis-field stabilization.
- `velis`: Architect-created, temporarily persistent topology directly in Genesis Field; **not** a physical sigil. Agricultural velis can enhance plant growth/nutrient uptake. Persistence depends on coherence and use; maintenance is possible.
- `raeon`: separate card-game rules inherited as a culturally relevant game, not as a magical domain.

## Inheritance and contamination boundary
This is a **new setting**. Reuse mechanisms, not automatically the protagonists, narrative arcs, political borders, or canon decisions of MK147/MK157. `_bricked` is mathematics authority; MK147 is fantasy infrastructure/worldbuilding authority; `_raeon` is card-game authority. All new Seven Domain specifics belong to this new project until deliberately merged elsewhere.
