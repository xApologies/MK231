# SEVEN DOMAINS OF MAGIC — EXHAUSTIVE THREAD RECOVERY ARCHIVE

**Version:** 0.2.0 | **Date:** 2026-10-09 | **Project:** New high-fantasy world | **Marker:** 🖤🌀🌈

## Foundational authorial axiom

> **These seven domains express magic as an existence.**

**Seven Domains, in the author's latest enumeration:** Six Realms; The Unwritten; The Borrowed Hours; The Thousand Thread; The Covenant Gardens; The Living Art; The Cartographers.

**Constraints in the same order:** compatibility; grammar and meaning; temporal obligations; existing connections; consent and obligation; biology and ecology; geometric consistency.

The domains began as seven possible fantasy novels, were combined into one world, briefly framed as Seven Arts, then **reinterpreted by the author as interdependent ontological domains**. The intermediate “Seven Arts” should never supersede the author's final definition. Magic is not a mana pool or merely a spell list. A conscious expression is called a *shaping*, produced through *transduction*; a magical existence may persist or grow without a conscious caster.

## Why this archive exists

The original v0.1.0 seed was far too compressed to recover the work from this conversation. This archive retains its original five files **plus expanded chronological reconstruction, a cross-domain casebook, and repository-verification notes**. It preserves both what was decided and the *reasoning and examples that gave those decisions meaning*. It explicitly labels suggested-but-unaccepted alternatives and open mathematical questions so a new thread doesn't invent fake canon.

## Read in this order

1. `CHRONOLOGY_AND_DECISION_EVOLUTION.md` — how every domain emerged, was combined, and was redefined; includes architecture corrections.
2. `SEVEN_DOMAINS.md` — the detailed canonical seven-domain overview, operations and constraints.
3. `CROSS_DOMAIN_CASEBOOK.md` — fireball, cube, healing, time borrowing, bonds, covenants, living magic, cartography, shapeshifting, and city infrastructure.
4. `WORLD_AND_LAYERS.md` — functional layer architecture, material realm, coexistence, orthogonal civic identity.
5. `REPOSITORY_INHERITANCE_VERIFIED.md` — directly checked Mk-147, _bricked and _raeon entry points and precise files.
6. `DECISIONS_AND_OPEN_QUESTIONS.md` — decision/open ledger from initial seed.
7. `REFERENCES.md` — additional source links.
8. `MANIFEST.json` — SHA-256 file integrity and version record.

## Source and authority convention

- **AUTHOR-DECIDED:** explicitly asserted, corrected, or confirmed by author.
- **CO-DEVELOPED:** assistant formulation adopted or built upon by author.
- **ILLUSTRATIVE:** explored as an example or possible plot; not automatically canon.
- **OPEN:** undecided, must not be filled in by guessing.
- **INHERITED:** supported by source repositories; source repository's own authority hierarchy applies.

## Core inheritance

`_bricked` provides Genesis mathematics and structural tools, **not** mandatory game/computer architecture. `Mk-147` provides already-developed fantasy infrastructure, ru’ne, sigils, material cultivation, civic architecture and cultural/worldbuilding mechanisms; binding circles are optional inheritance. `_raeon` is an in-world card game, not an eighth magical domain. The new fantasy world does **not** automatically inherit MK147/MK157 characters or plot.

## Architectural correction that must survive handoff

The Material Realm is **not generic Renaissance architecture with magical embellishments**. It is strongly orthogonal **Minecraft/Lego-like cultivated stone construction** (rectangular blocks, square towers, geometric layouts), with living growth, trees, vines, gardens and abundant waterways breaking up the straight lines. Both built forms and environmental growth/water infrastructure are enabled by sigils and Genesis engineering. Romanticized late 17th/early 18th century is the *social/cultural aesthetic and preindustrial trajectory*, not a license to replace the nine authoritative architectural reference images with round-arched European buildings. Those nine original images are not embedded in this archive; attach them when precise visual reference is needed.

## Scope honesty

This is an **exhaustive topical reconstruction** of the decisions and meaningful examples visible in the originating conversation, **not a verbatim export of every message**. No complete axiomatic mathematical theory has yet been agreed. Exhaustive archival preservation does **not** mean all questions about the Seven Domains have been answered. No GitHub repositories were changed.
