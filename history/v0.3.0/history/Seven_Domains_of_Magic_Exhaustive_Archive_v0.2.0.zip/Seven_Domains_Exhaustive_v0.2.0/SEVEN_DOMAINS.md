# Seven Domains of Magic — Foundational Seed
Version 0.1.0 · 2026-10-09 · Conversation-established baseline · 🖤🌀🌈

## Governing axiom
**The Seven Domains express Magic as an Existence.** Magic is not merely fuel, a spell list, or a finite mana reservoir. The seven domains are interdependent ontological conditions describing how magical existence can be supported, interpreted, timed, related, sustained, cultivated, and geometrically admitted. A conscious caster is not always required for magic to persist.

## Canonical table
| Domain | Fundamental operation | Principal constraint |
|---|---|---|
| Six Realms | Exist across realm structures | Compatibility |
| The Unwritten | Express valid statements | Grammar and meaning |
| The Borrowed Hours | Transfer duration | Temporal obligations |
| The Thousand Thread | Modify relationships | Existing connections |
| The Covenant Gardens | Negotiate agreements | Consent and obligation |
| The Living Art | Cultivate magical life | Biology and ecology |
| The Cartographers | Alter spatial adjacency | Geometric consistency |

Names follow the user's latest explicit enumeration. Earlier brainstorming variants were **Thousand Threads**, **Thousand Strands**, and **Covenant Garden**; they are aliases, not extra domains.

## 1. Six Realms — Compatibility
Six distinct realm structures are identified Red, Orange, Yellow, Green, Blue, Violet. These colors are *structural identities*, not mandatory colors of their landscapes, elemental categories, spell schools, or fixed power rankings. The White/Human/Material Realm is the superposition of all six structures. It supports matter and energy in spacetime, Genesis-field manipulation, and coexistence of all six native magical populations with humanity.

Humans naturally inhabit the Material Realm and require assistance or a compatibility mechanism to enter/survive a native realm. Native magical entities can visit the Material Realm. Dragons, unicorns, prime elementals, and other magical beings can manifest humanoid forms and coexist openly in human, elven, and dwarven society; their existence is publicly known, even when individual identities are private. Exact assignments of six principal races to six realms are **OPEN**. Dragon/Red and Unicorn/Violet were examples, not locks. Realm origin does not impose a spell list. A helium-4 landscape was an imaginative possibility, not settled geography.

A conceptual notation is `MaterialRealm = Superpose(R,O,Y,G,B,V)`; no rigorous quantum operator has been specified. White is a realm expression, not an eighth domain of magic. **Constraint:** a configuration must be compatible with the realm supporting it. **Open:** transit mechanism, biological compatibility, home-realm conditions, six civilizations, and cross-realm hybrids.

## 2. The Unwritten — Grammar and meaning
Magic can be expressed through meaningful and valid language: spoken statements, writing, inscriptions, ru’ne, sigils, and other grammatical structures. The user interprets this domain as how magic possesses grammar and meaning. A syntactically valid statement need not be semantically coherent or admissible under the other domains. A sigil can encode a repeatable instruction; an inscription can express conditions or identity. This is not necessarily limited to spoken incantations.

**Constraint:** grammar and meaning must be valid, interpretable, and relevant to the intended expression. **Illustration (not canon):** a healing inscription that cannot identify its target cannot reliably apply its instruction. **Open:** formal syntax, semantics, ambiguity resolution, whether language can directly alter reality, and how sigil language relates to Genesis structural language.

## 3. The Borrowed Hours — Temporal obligations
This domain governs duration, temporal scale, and the obligations of modifying temporal relationships. Its scope extends from seconds and hours to centuries, millennia, and even the lifespan of entire existences. Distinguish (a) duration, (b) event ordering, and (c) the obligation incurred when time is transferred, deferred, accelerated, or borrowed. The user also connects this domain to permitted geometry within temporal domains.

**Constraint:** temporal obligations must be satisfied; duration cannot simply be assumed free of consequence. **Illustrations (not canon):** accelerated recovery borrowing an interval; postponing a collapse; sustaining a centuries-long enchantment. **Open:** exact temporal accounting, conservation laws, paradox restrictions, and whether transfers are literal or descriptive. No unrestricted time travel is established.

## 4. The Thousand Thread — Existing connections
This domain governs relationships among realms, identities, temporal obligations, statements, objects, living systems, and spatial locations. It provides a relational layer: what is connected, how, and under what admissible changes. Its central operation is to modify relationships, not to fabricate arbitrary relations without grounding.

**Constraint:** an existing connection must support the operation, with the meaning of 'existing' still to be formalized. **Illustrations (not canon):** a weapon's link to its bearer; a spell's link to its sustaining sigil; a bridge's connection to its supports; a habitat's connection to a living organism. **Open:** connection creation, severance, persistence, identity under rewiring, and whether relationships are literal visible strands.

## 5. The Covenant Gardens — Consent and obligation
This domain governs agreements and obligations associated with living existence. Original brainstorming considered explicit negotiations with conscious magical powers (river spirits, mountains, storms). The user's expanded interpretation also includes the conditions under which biological existence sustains itself: cooperation, exchange, and dependence among living structures.

**Critical distinction:** consent by a conscious entity is not the same as a nonconscious biological dependency. Use 'covenant' as a formal or metaphorical term for structural obligations where no agent is present; do not imply cells provide informed consent. **Constraint:** agreements or sustaining obligations must be respected. **Illustrations (not canon):** a river spirit agrees to aid a town; a living garden depends on reciprocal exchange. **Open:** personhood of spirits, nonconscious covenants, enforcement, and breach consequences.

## 6. The Living Art — Biology and ecology
Magic may be grown, bred, grafted, cultivated, and maintained as an organized existence. A spell can be life-like, responsive, adaptive, and potentially self-sustaining without being conscious. This is the user's key extension: spells can *themselves* be alive in an organizational sense, not necessarily sentient. Living Art explains why magic can occur as a cultivated or naturally organized phenomenon, including magical ecosystems.

**Constraint:** biology and ecology: a cultivated magical existence must have a viable organization and environmental relations. **Illustrations (not canon):** a healing spell that detects injury and adapts; living armor; a self-maintaining magical garden; a spell that completes its function and dissipates. **Open:** reproduction, mutation, evolution, metabolism, whether all spells are alive, and criteria separating a spell from an organism. Distinct from Covenant Gardens, which governs living obligations and agreements.

## 7. The Cartographers — Geometric consistency
The Cartographers governs geometry, topology, admissible spatial configurations, boundaries, and adjacency. It is the most explicit fantasy-facing expression of the Genesis mathematical substrate. A map or geometric construction can express spatial relationships, but valid geometry does not by itself override the other six domains.

**Constraint:** geometric consistency and admissibility. **Illustrations:** growing a one-foot cube in a bounded Genesis-field sigil array is simpler to specify than a curved arch; a shaped stone block can have orthogonal interlocking faces; a passage connecting remote locations must satisfy its spatial topology. **Open:** formal geometry, costs of curved versus orthogonal growth, portal rules, and whether spatial adjacency can be altered without movement.

## Domain relationships
The domains are not seven sequential casting steps. A fireball, living spell, grown stone block, humanoid dragon, and magical watercourse may engage different domains simultaneously. A conscious magical expression is called a **shaping** and is produced through **transduction** in the inherited fantasy language. Natural magical existence need not be a shaping performed by a person. Magic is permitted to be abundant and wondrous without a universal mana meter.

**Conceptual only:** `MagicalExistence = AdmissibleExpression(GenesisField; D1..D7)`. This is neither a proved equation nor an implemented mathematical operator.
