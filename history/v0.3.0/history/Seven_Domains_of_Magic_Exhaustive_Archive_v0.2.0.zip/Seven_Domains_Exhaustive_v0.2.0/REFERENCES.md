# Source repositories and verification

- https://github.com/xApologies/_bricked — mathematical/Genesis foundation. README confirmed source authorities include `genesis_mathematics/`, `chirality_fabric/`, and Rainbow Road; game/runtime requirements are not imported automatically.
- https://github.com/xApologies/Mk-147 — fantasy-world infrastructure and worldbuilding. README/INDEX and these documents were consulted:
  - `live-model/04_SYSTEMS/SIGIL_ENGINEERING.md`
  - `live-model/04_SYSTEMS/ARCHITECTS_VELIS.md`
  - `live-model/02_WORLD/KINGDOM_SETTLEMENTS.md`
  - `live-model/04_SYSTEMS/ALCHEMY.md` (index reference; full content not audited for this seed)
- https://github.com/xApologies/_raeon — culturally inherited card game; README confirms game design and independent rule authority.

This archive synthesizes the user's **current conversation decisions** and targeted verified repository entry points; it is **not** a full repository crawl, and it does not claim that every mechanism has been audited against source files. The nine user-uploaded architectural images are referenced conceptually but not bundled. No remote repository was modified.
